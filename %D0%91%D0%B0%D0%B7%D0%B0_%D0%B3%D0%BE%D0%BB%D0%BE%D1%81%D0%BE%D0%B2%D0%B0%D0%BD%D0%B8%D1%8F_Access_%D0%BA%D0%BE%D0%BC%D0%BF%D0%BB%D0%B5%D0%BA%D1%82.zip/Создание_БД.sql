﻿-- База данных: Приложение для голосования
-- СУБД: Microsoft Access
-- ВАЖНО: выполняйте каждый блок CREATE TABLE отдельно в Access:
-- Создание -> Конструктор запросов -> Режим SQL -> Выполнить.
-- Затем выполните блоки CREATE INDEX отдельно.

CREATE TABLE [Пользователи] (
    [КодПользователя] AUTOINCREMENT CONSTRAINT [PK_Пользователи] PRIMARY KEY,
    [Логин] TEXT(50) NOT NULL,
    [ХешПароля] TEXT(255) NOT NULL,
    [Имя] TEXT(100) NOT NULL,
    [ЭлектроннаяПочта] TEXT(150),
    [Роль] TEXT(20) NOT NULL,
    [ДатаРегистрации] DATETIME
);

CREATE TABLE [Голосования] (
    [КодГолосования] AUTOINCREMENT CONSTRAINT [PK_Голосования] PRIMARY KEY,
    [Название] TEXT(150) NOT NULL,
    [Описание] MEMO,
    [ДатаСоздания] DATETIME,
    [ДатаОкончания] DATETIME,
    [Активно] YESNO
);

CREATE TABLE [ВариантыОтветов] (
    [КодВарианта] AUTOINCREMENT CONSTRAINT [PK_ВариантыОтветов] PRIMARY KEY,
    [КодГолосования] LONG NOT NULL,
    [ТекстВарианта] TEXT(255) NOT NULL
);

CREATE TABLE [Голоса] (
    [КодГолоса] AUTOINCREMENT CONSTRAINT [PK_Голоса] PRIMARY KEY,
    [КодПользователя] LONG NOT NULL,
    [КодГолосования] LONG NOT NULL,
    [КодВарианта] LONG NOT NULL,
    [ДатаГолосования] DATETIME
);

-- Индексы: каждый CREATE INDEX выполняйте отдельным запросом.
CREATE UNIQUE INDEX [UX_Пользователи_Логин] ON [Пользователи] ([Логин]);
CREATE UNIQUE INDEX [UX_Пользователи_Почта] ON [Пользователи] ([ЭлектроннаяПочта]);
CREATE UNIQUE INDEX [UX_Голос_Пользователь_Голосование] ON [Голоса] ([КодПользователя], [КодГолосования]);
CREATE INDEX [IX_Варианты_Голосование] ON [ВариантыОтветов] ([КодГолосования]);
CREATE INDEX [IX_Голоса_Голосование] ON [Голоса] ([КодГолосования]);

-- Связи (выполняйте каждый ALTER TABLE отдельно).
ALTER TABLE [ВариантыОтветов]
ADD CONSTRAINT [FK_Варианты_Голосования]
FOREIGN KEY ([КодГолосования]) REFERENCES [Голосования] ([КодГолосования]);

ALTER TABLE [Голоса]
ADD CONSTRAINT [FK_Голоса_Пользователи]
FOREIGN KEY ([КодПользователя]) REFERENCES [Пользователи] ([КодПользователя]);

ALTER TABLE [Голоса]
ADD CONSTRAINT [FK_Голоса_Голосования]
FOREIGN KEY ([КодГолосования]) REFERENCES [Голосования] ([КодГолосования]);

ALTER TABLE [Голоса]
ADD CONSTRAINT [FK_Голоса_Варианты]
FOREIGN KEY ([КодВарианта]) REFERENCES [ВариантыОтветов] ([КодВарианта]);
